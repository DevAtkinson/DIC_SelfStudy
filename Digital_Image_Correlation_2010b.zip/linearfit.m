function F = linearfit(x,xdata)
        F = x(1)*xdata+x(2);